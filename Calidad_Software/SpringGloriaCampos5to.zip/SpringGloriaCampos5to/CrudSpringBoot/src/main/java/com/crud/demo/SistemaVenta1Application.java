package com.crud.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaVenta1Application {

	public static void main(String[] args) {
		SpringApplication.run(SistemaVenta1Application.class, args);
	}

}
